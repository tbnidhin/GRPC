﻿using Grpcapp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GRPCServer
{
    public class GRPCServImpl:Grpcapp.GRPCApp.GRPCAppBase
    {
        public Task<OutData> GetAppData() {
            return Task.FromResult(new OutData() { OutputData = "Test" });
        }
    }
}
