﻿using Grpc.Core;
using Grpcapp;
using System;

namespace GRPCClient
{
    class Program
    {
        public class GRPCClient {
            readonly Grpcapp.GRPCApp.GRPCAppClient appClient;

            public GRPCClient(Grpcapp.GRPCApp.GRPCAppClient AppClient) {
                this.appClient = AppClient;
            }
        }

        static void Main(string[] args)
        {
            try
            {

                var channel = new Channel("127.0.0.1:50052", ChannelCredentials.Insecure);
                var client = new GRPCApp.GRPCAppClient(channel);
                InData inData = new InData() { InputData = 2 };
                OutData outData = client.GetAppData(inData);
            }
            catch (Exception)
            {

                throw;
            }
            //var client = new GRPCClient(new ) //GRPCClient(new GRPCClient.RouteGuideClient(channel));
        }
    }
}
