﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Model
{
    public class Lock
    {
        public string LockId { get; set; }
        public DateTime LockDateTime { get; set; }
        public bool LockStatus { get; set; }
    }
}
