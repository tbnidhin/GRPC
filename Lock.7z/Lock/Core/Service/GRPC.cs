﻿using System;
using System.Collections.Generic;
using System.Text;
using Core.Repository.Interface;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using CustomLock = Broadcast.Lock;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Grpc.Core;

namespace Core.Service
{
    public class GRPC: CustomLock.Service.ServiceBase, IHostedService
    {
        private readonly IConfiguration Config;
        private readonly IDataRepository DataRepository;
        //private readonly ICommandRepository CommandRepository;
        private readonly ILogger<GRPC> Logger;

        private Server ServerInstance;

        public GRPC(IConfiguration config, IDataRepository dataRepository, ICommandRepository commandRepository)
        {
            this.Config = config;
            this.DataRepository = dataRepository;
            //this.CommandRepository = commandRepository;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            //var config = Config.GetGRPCConfigObject();
            this.ServerInstance = new Server
            {
                Ports = { new ServerPort("localhost", 50052, ServerCredentials.Insecure) },
                Services = { Broadcast.Lock.Service.BindService(this) }
            };
            this.ServerInstance.Start();
            //Console.WriteLine("RouteGuide server listening on port " + Port);
            //Console.WriteLine("Press any key to stop the server...");
            //Console.ReadKey();

            //server.ShutdownAsync().Wait();
            return Task.CompletedTask;
        }
        public Task StopAsync(CancellationToken cancellationToken)
        {
            this.Logger.LogInformation(" stopping gRPC service");
            return this.ServerInstance.ShutdownAsync();
        }

        public override Task<CustomLock.CheckResponse> Check(CustomLock.CheckRequest request, ServerCallContext context)
        {
            return base.Check(request, context);
        }

        public override Task<CustomLock.LockResponse> Lock(CustomLock.LockRequest request, ServerCallContext context)
        {
            return base.Lock(request, context);
        }

        public override Task<CustomLock.ReleaseResponse> Release(CustomLock.ReleaseRequest request, ServerCallContext context)
        {
            return base.Release(request, context);
        }
    }
}
