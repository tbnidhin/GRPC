﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Repository.Interface
{
    public interface IDataRepository
    {
    }
}
