﻿using Core.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Repository
{
    public class CommandRepository : ICommandRepository
    {
    }
}
