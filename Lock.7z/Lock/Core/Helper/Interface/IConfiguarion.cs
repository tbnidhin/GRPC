﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Helper
{
    public interface IConfiguarion
    {
    }
}
