﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace Core.Helper
{
    static class ConfigHelperExtensions
    {
        private const string HostName = "HostName";
        private const string Port = "Port";
        public static dynamic GetGRPCConfigObject(this IConfiguration config)
        {
            IConfigurationSection thisConfig = config.GetSection("GRPC");
            return new //return an object to init RabbitMQ connection
            {
                HostName = thisConfig.GetValue<string>(HostName),
                Port = thisConfig.GetValue<int>(Port)
            };
        }
    }
}
