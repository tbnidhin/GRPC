using NUnit.Framework;
using Core.Service;
using Core.Repository;
using Core.Repository.Interface;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Broadcast.Lock;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()

        {
            Test1();
        }

        [Test]
        public void Test1()
        {
            IConfiguration config; IDataRepository dataRepository; ICommandRepository commandRepository;
            config = new ConfigurationBuilder().Build();
            dataRepository = new DataRepository();
            commandRepository = new CommandRepository();
            GRPC grpc = new GRPC(config,dataRepository,commandRepository);
            CheckRequest checkRequest = new CheckRequest();
            grpc.Check(checkRequest,null);
            LockRequest lockRequest = new LockRequest();
            grpc.Lock(lockRequest, null);
            ReleaseRequest releaseRequest = new ReleaseRequest();
            grpc.Release(releaseRequest, null);
            Assert.Pass();
        }
    }
}