﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lock.Model
{
    class Lock
    {
    }
}
